package handlers

import (
	"math/rand"
	"net/http"
	"time"

	"github.com/labstack/echo/v4"
)

type Telemetry struct {
	Timestamp string  `json:"timestamp"`
	Subsystem string  `json:"subsystem"`
	Metric    string  `json:"metric"`
	Value     float64 `json:"value"`
	Unit      string  `json:"unit"`
	Status    string  `json:"status"`
}

func generateTimeSeriesTelemetry(points int, interval time.Duration) []Telemetry {
	var data []Telemetry
	now := time.Now().UTC()

	batteryLevel := 100.0

	for i := 0; i < points; i++ {
		ts := now.Add(-interval * time.Duration(i)).Format(time.RFC3339)

		batteryLevel -= rand.Float64() * 1.5
		if batteryLevel < 20 {
			batteryLevel = 100.0
		}

		data = append(data,
			Telemetry{
				Timestamp: ts,
				Subsystem: "power",
				Metric:    "battery_voltage",
				Value:     14.5 + rand.Float64()*0.5,
				Unit:      "V",
				Status:    "nominal",
			},
			Telemetry{
				Timestamp: ts,
				Subsystem: "power",
				Metric:    "power_level",
				Value:     batteryLevel,
				Unit:      "%",
				Status:    "nominal",
			},
			Telemetry{
				Timestamp: ts,
				Subsystem: "thermal",
				Metric:    "cpu_temp",
				Value:     40 + rand.Float64()*10,
				Unit:      "°C",
				Status:    "nominal",
			},
			Telemetry{
				Timestamp: ts,
				Subsystem: "thermal",
				Metric:    "thermal_level",
				Value:     3 + rand.Float64()*2,
				Unit:      "level",
				Status:    "nominal",
			},
			Telemetry{
				Timestamp: ts,
				Subsystem: "comms",
				Metric:    "signal_strength",
				Value:     75 + rand.Float64()*10,
				Unit:      "%",
				Status:    "nominal",
			},
			Telemetry{
				Timestamp: ts,
				Subsystem: "payload",
				Metric:    "payload_status",
				Value:     float64(rand.Intn(2)), // 0 or 1
				Unit:      "status",
				Status:    "nominal",
			},
			Telemetry{
				Timestamp: ts,
				Subsystem: "payload",
				Metric:    "payload_temp",
				Value:     30 + rand.Float64()*5,
				Unit:      "°C",
				Status:    "nominal",
			},
		)
	}

	return data
}

// Handler returns mock telemetry data in JSON
func GetMockTelemetryHandler() echo.HandlerFunc {
	return func(c echo.Context) error {
		// 100 data points, 1-minute intervals
		mockData := generateTimeSeriesTelemetry(100, time.Minute)

		return c.JSON(http.StatusOK, mockData)
	}
}
