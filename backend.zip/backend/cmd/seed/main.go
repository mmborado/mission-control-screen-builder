package main

import (
	"database/sql"
	"fmt"
	"log"
	"math/rand"
	"os"
	"time"

	_ "github.com/lib/pq"
)

var metrics = []struct {
	Subsystem string
	Metric    string
	Unit      string
	Min       float64
	Max       float64
}{
	{"thermal", "cpu_temp", "°C", 40, 55},
	{"power", "battery_voltage", "V", 14.5, 15.2},
	{"comms", "signal_strength", "%", 70, 85},
	{"payload", "payload_temp", "°C", 20, 40},
	{"thermal", "thermal_level", "kW", 1.0, 2.5},
}

func main() {
	dbURL := os.Getenv("DATABASE_URL")
	if dbURL == "" {
		dbURL = "postgres://missioncontrol:password123@localhost:5432/missioncontrol_demo?sslmode=disable"
	}

	db, err := sql.Open("postgres", dbURL)
	if err != nil {
		log.Fatalf("Failed to connect to DB: %v", err)
	}
	defer db.Close()

	start := time.Now().Add(-24 * time.Hour)
	interval := time.Minute

	tx, err := db.Begin()
	if err != nil {
		log.Fatal(err)
	}

	stmt, err := tx.Prepare(`
		INSERT INTO telemetry (timestamp, subsystem, metric, value, unit, status)
		VALUES ($1, $2, $3, $4, $5, $6)
	`)
	if err != nil {
		log.Fatal(err)
	}
	defer stmt.Close()

	rand.Seed(time.Now().UnixNano())

	for t := start; t.Before(time.Now()); t = t.Add(interval) {
		for _, m := range metrics {
			value := m.Min + rand.Float64()*(m.Max-m.Min)
			status := "nominal"
			if rand.Float64() < 0.02 {
				status = "warning"
			}

			_, err := stmt.Exec(t.UTC(), m.Subsystem, m.Metric, value, m.Unit, status)
			if err != nil {
				log.Fatalf("Insert failed: %v", err)
			}
		}
	}

	if err := tx.Commit(); err != nil {
		log.Fatal(err)
	}

	fmt.Println("✅ Telemetry data seeded successfully.")
}
