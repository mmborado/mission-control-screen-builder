package main

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"

	"github.com/joho/godotenv"
	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	_ "github.com/lib/pq"
	"github.com/mmborado/mission-control/handlers"
)



func main() {
	godotenv.Load()

	db, err := sql.Open("postgres", os.Getenv("DATABASE_URL"))
	if err != nil {
		log.Fatal("Failed to connect to DB:", err)
	}
	defer db.Close()

	if err := db.Ping(); err != nil {
		log.Fatal("DB not reachable:", err)
	}

	e := echo.New()

	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: []string{"http://localhost:5173"}, 
		AllowMethods: []string{echo.GET, echo.POST, echo.PUT, echo.DELETE, echo.OPTIONS},
	}))

	e.GET("/health", func(c echo.Context) error {
		if err := db.Ping(); err != nil {
			return c.JSON(http.StatusInternalServerError, map[string]string{"status": "DB Unreachable"})
		}
		return c.JSON(http.StatusOK, map[string]string{"status": "OK"})
	})

	e.GET("/telemetry", telemetryHandler)
	e.GET("ws/telemetry", telemetryWebSocketHandler);
	e.GET("/api/telemetry/historical", handlers.GetHistoricalTelemetryHandler(db))
	// e.GET("/api/telemetry/mock", handlers.GetMockTelemetryHandler())
	e.GET("/api/commands", handlers.GetCommandHistoryHandler(db))
	e.POST("/api/commands", handlers.PostCommandHandler(db))

	port := os.Getenv("PORT")
	fmt.Println("Server running on port", port)
	e.Logger.Fatal(e.Start(":" + port))
}
